//
//  DateViewController.swift
//  PrototypeCalendar4
//
//  Created by Jing-Jing Shen on 12/7/19.
//  Copyright © 2019 CS50. All rights reserved.
//


import UIKit
import SQLite3

struct MyVariables
{
    static var displayOfficialDate = ""
    static var displayMyNote = ""
}

class DateViewController: UIViewController {
    
// 1. CHOOSING DATE
    @IBOutlet var datePickerSelection: UIDatePicker!
    
    // below from https://stackoverflow.com/questions/42111067/how-to-convert-date-picker-value-into-string-in-swift-3-0 AND https://www.youtube.com/watch?v=kML_2TkWEsk 2:57
    
    @IBOutlet var test: UITextField!
    
    // var inputDate: String = ""
    // var officialDate: String = "OFFICIALDATE" // USE THIS ONE?
    @IBAction func dateChanged(_ sender: Any) {
        let dateFormatter = DateFormatter()
        //var chosenDate = dateFormatter.string(from: datePickerSelection.date) // a string
        // test.inputView = datePickerSelection
        dateFormatter.dateStyle = DateFormatter.Style.medium
        MyVariables.displayOfficialDate = dateFormatter.string(from: datePickerSelection.date)
        //officialDate = dateFormatter.string(from: datePickerSelection.date)
        // test.text = dateFormatter.string(from: datePickerSelection.date)
        
        test.text = dateFormatter.string(from: (sender as AnyObject).date!) // displays date from date picker 
    }
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
 // 2. NOTES
    // use functions here
    @IBOutlet var notesTextView: UITextView!
    
    func inputNotes(sender: UITextView)
    {
        // this should be a string
        MyVariables.displayMyNote = notesTextView.text
    } // end func
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // every time view comes into focus, this is called
    override func viewDidLoad() {
        super.viewDidLoad()
        dateChanged(datePickerSelection as Any)
        guard let date = date else { // no date
            return
        }
        // was considering notesTextView.text = MyVariables.displayMyNote // displays stored note
        notesTextView.text = DateManager.shared.retrieveNote()
    }
    
    var date: DateData?
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // was considering guard let date = date else { // no date
        //    return
        // }
        // notesTextView.text = MyVariables.displayMyNote // displays stored note
        // notesTextView.text = DateManager.shared.retrieveNote()
        notesTextView.text = date?.inputNote // gets note to appear
    }
      
      // save note when user hits back button and before view disappears
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        guard var date = date else { // no date
            return
        }
        date.inputNote = notesTextView.text
        inputNotes(sender: notesTextView) // where to put this
        DateManager.shared.saveDate(date: date)
    }
}
        


