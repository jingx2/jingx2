//
//  ViewController.swift
//  PrototypeCalendar4
//
//  Created by Jing-Jing Shen on 12/1/19.
//  Copyright © 2019 CS50. All rights reserved.
//

import UIKit

// added
enum MyTheme {
    case light
    case dark
}

class ViewController: UIViewController {

    var theme = MyTheme.dark // added
    
    //------------------------------
    // added this later
    var dates: [DateData] = [] // empty array of dates
    //------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "RetroSpec"
        self.navigationController?.navigationBar.isTranslucent = false
        self.view.backgroundColor = Style.bgColor
               
        view.addSubview(calendarView)
        calendarView.topAnchor.constraint(equalTo: view.topAnchor, constant: 30).isActive = true
        calendarView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -12).isActive = true
        calendarView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 12).isActive = true
        calendarView.heightAnchor.constraint(equalToConstant: 365).isActive = true
               
        let rightBarBtn = UIBarButtonItem(title: "Light", style: .plain, target: self, action: #selector(rightBarBtnAction))
        self.navigationItem.rightBarButtonItem = rightBarBtn
    }
           
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        calendarView.myCollectionView.collectionViewLayout.invalidateLayout()
    }
           
    @objc func rightBarBtnAction(sender: UIBarButtonItem) {
        if theme == .dark {
            sender.title = "Dark"
            theme = .light
            Style.themeLight()
        } else {
            sender.title = "Light"
            theme = .dark
            Style.themeDark()
        }
        self.view.backgroundColor=Style.bgColor
        calendarView.changeTheme()
    }
           
    let calendarView: CalendarView = {
        let v = CalendarView(theme: MyTheme.dark)
        v.translatesAutoresizingMaskIntoConstraints=false
        return v
    }()

    // SEGUE
    @IBAction func submitThisDate(_ sender: Any) {
        performSegue(withIdentifier: "segToDate", sender: self)
        let _ = DateManager.shared.create()
        
    }
   
    
    
    // REFRESH PAGE
    func reload() {
        dates = DateManager.shared.getDates()
        view.setNeedsDisplay()
    }
    
    // added just now
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }
}



