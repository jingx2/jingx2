//
//  DateData.swift
//  PrototypeCalendar4
//
//  Created by Jing-Jing Shen on 12/7/19.
//  Copyright © 2019 CS50. All rights reserved.
//

// based on NOTES
// This is where we store where the entries come from

import Foundation
import SQLite3

struct DateData {
    var id: Int32 // id for the date
    var inputDate: String
    // officialDate // this is from DateViewController?
    var inputNote: String
}

// classes similar to structs but can also have methods
// this class handles connecting to database, creating notes, getting notes, updating notes
class DateManager {
    var database: OpaquePointer? // pointer, ref to our db
    
    static let shared = DateManager()
    // static lets you access property without instance
    // every time you visit this code, don't overwrite code (leave it as is)
    private init() { // no one else can call NoteManager()
    }
    
    // path to file on user's phone
    func connect() {
        if database != nil { // only connect to db 1x
            return
        }
        
        // path to db file on user's phone
        // get path to somewhere on device where it's safe for you to save read/write files
        // specify where you want file to be stored
        let databaseURL = try! FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: false // if file no exist, create it
        ).appendingPathComponent("dates.sqlite") // ??? create table below and then use it?
        
        // establish connection to database and open file
        // 1st param is file to open, 2nd is where we want to est cxn (address)
        if sqlite3_open(databaseURL.path, &database) != SQLITE_OK { // unsuccessful open
            print("Error opening database")
            return
        }
        
        // make sure table we need to exist exists
        if sqlite3_exec( // successful open
            database,
            """
            CREATE TABLE IF NOT EXISTS dates (inputDate TEXT, inputNote TEXT)
            """,
            nil,
            nil,
            nil
        ) != SQLITE_OK {
            print("Error creating table: \(String(cString: sqlite3_errmsg(database)!))")
        }
    }
    
    // create the date
    func create() -> Int { // get id of row you created
        connect()
        
        // 3 step process to execute query
        
        var statement: OpaquePointer? = nil
        // 1. prepare query, 2. execute query (in a loop or not)
        // default text for new note

        if sqlite3_prepare_v2(
            database, "INSERT INTO dates (inputDate, inputNote) VALUES (?, ?)",
            -1,
            &statement,
            nil
        ) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, NSString(string: MyVariables.displayOfficialDate).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, NSString(string: MyVariables.displayMyNote).utf8String, -1, nil)
            if sqlite3_step(statement) != SQLITE_DONE {
                print("Error inserting date")
            }
        }
        else {
            print("Error creating date insert statement")
        }
        // 3. finalize query, cannot use statement again
        sqlite3_finalize(statement)
        return Int(sqlite3_last_insert_rowid(database))
    } // creates a row_id here
    
    // get all of the dates from the database
    func getDates() -> [DateData] {
        connect() // connect to database
        
        var result: [DateData] = [] // array of the date entries
        var statement: OpaquePointer? = nil
        // add on other parts later
        if sqlite3_prepare_v2(database, "SELECT rowid, inputDate, inputNote FROM dates", -1, &statement, nil) == SQLITE_OK {
            // convert to dates object
            while sqlite3_step(statement) == SQLITE_ROW {
                result.append(DateData(
                    id: sqlite3_column_int(statement, 0),
                    inputDate: String(cString: sqlite3_column_text(statement, 1)),
                    inputNote: String(cString: sqlite3_column_text(statement, 1))
                ))
            }
        }
        sqlite3_finalize(statement) // cleanup BTS
        return result
    }
    
    // write this function here and call it in the other class
    var retrievedNote: String = ""
    func retrieveNote() -> String
     {
        print("called retrieve note")
         connect()
         var statement: OpaquePointer? = nil // add this to every function?, to see if return succeeded
        var date: [DateData] = []
        
         // because every dates entry must have a note? Or even an empty one
         if sqlite3_prepare_v2(database, "SELECT inputNote FROM dates WHERE inputDate = ?, inputNote = ?", -1, &statement, nil) == SQLITE_OK
         { sqlite3_bind_text(statement, 1, NSString(string: MyVariables.displayOfficialDate).utf8String, -1, nil); sqlite3_bind_text(statement, 2, NSString(string: MyVariables.displayMyNote).utf8String, -1, nil)
            
            date.insert(DateData(id: sqlite3_column_int(statement, 0), inputDate: String(cString: sqlite3_column_text(statement, 1)), inputNote: String(cString: sqlite3_column_text(statement, 2))), at: 0)
            }
         sqlite3_finalize(statement) // cleanup BTS
        
        retrievedNote = date.first?.inputNote ?? " "
        print(date)
        return retrievedNote
    }
    
    // Parameter binding to safely pass data into query
    // Convert data from Swift-friendly to SQL-friendly format
    func saveDate(date: DateData) {
        print("saveDate")
        connect()
        
        var statement: OpaquePointer? = nil
        if sqlite3_prepare_v2(
            database,
            "INSERT INTO dates (inputDate, inputNote) VALUES (?, ?)",
                -1,
                &statement,
                nil
            ) == SQLITE_OK {
                sqlite3_bind_text(statement, 1, NSString(string: MyVariables.displayOfficialDate).utf8String, -1, nil)
                sqlite3_bind_text(statement, 2, NSString(string: MyVariables.displayMyNote).utf8String, -1, nil)
                if sqlite3_step(statement) != SQLITE_DONE {
                    print("Error inserting date")
                }
            }
        else {
            print("Error creating date update statement")
        }
        
        sqlite3_finalize(statement)
        
    }
    
} // end class
